package com.example.demo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 加载 StaggeredFragment 到容器
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, StaggeredFragment())
            .commit()
    }
}
