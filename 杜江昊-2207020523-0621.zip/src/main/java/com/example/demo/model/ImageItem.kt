package com.example.demo.model

data class ImageItem(
    val id: String,
    val imageUrl: String
)
